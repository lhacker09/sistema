<?php
//require_once "Views/autoload.php";

class Plantilla{
    
public function mostrarPlantilla(){
    include "Views/Plantilla.php";
}


}