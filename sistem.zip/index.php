<?php

require_once "Controllers/Plantilla.php";

$plantilla = new Plantilla();
$plantilla -> mostrarPlantilla();
