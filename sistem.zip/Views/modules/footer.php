            <footer class="main-footer">
                <div class="footer-left">
                    Copyright &copy; <div class="bullet"></div> Moshè Brito - <a class="text-success" target="blanck" href="https://shemoec.com/">Shemo.ec</a>
                </div>
                <div class="footer-right">Versión 0.1.4
                </div>
            </footer>
 

    <script src="Assets/js/jquery.min.js"></script>
    <!-- General JS Scripts -->
    <script src="Assets/js/app.min.js"></script>
    <!-- JS Libraies -->

  <!-- JS Libraies -->
  <script src="Assets/bundles/sweetalert/sweetalert.min.js"></script>
    <!-- DATATABLES -->
  <script src="Assets/bundles/datatables/datatables.min.js"></script>
  <script src="Assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="Assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="Assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="Assets/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="Assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="Assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="Assets/bundles/datatables/export-tables/buttons.print.min.js"></script>

    <!-- Template JS File -->
    <script src="Assets/js/scripts.js"></script>

<script type="text/javascript" src="Assets/bundles/filestyle/bootstrap-filestyle.min.js"> </script>
</body>


</html>